declare module native {
	export class Array<T> {
		public constructor();
	}
}

import javaioInputStream = java.io.InputStream;
import javanetSocket = java.net.Socket;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export class ClientHandler {
					public run(): void;
					public close(): void;
					public constructor(param0: org.nanohttpd.protocols.http.NanoHTTPD, param1: javaioInputStream, param2: javanetSocket);
				}
			}
		}
	}
}

import javaioOutputStream = java.io.OutputStream;
import javanetInetAddress = java.net.InetAddress;
import javautilMap = java.util.Map;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export class HTTPSession {
					public static POST_DATA: string;
					public static BUFSIZE: number;
					public static MAX_HEADER_SIZE: number;
					public execute(): void;
					public getInputStream(): javaioInputStream;
					public getUri(): string;
					public getHeaders(): java.util.Map<any, any>;
					public constructor(param0: org.nanohttpd.protocols.http.NanoHTTPD, param1: org.nanohttpd.protocols.http.tempfiles.ITempFileManager, param2: javaioInputStream, param3: javaioOutputStream);
					public constructor(param0: org.nanohttpd.protocols.http.NanoHTTPD, param1: org.nanohttpd.protocols.http.tempfiles.ITempFileManager, param2: javaioInputStream, param3: javaioOutputStream, param4: javanetInetAddress);
					public getParms(): java.util.Map<any, any>;
					public getQueryParameterString(): string;
					public parseBody(param0: java.util.Map<any, any>): void;
					public getMethod(): org.nanohttpd.protocols.http.request.Method;
					public getCookies(): org.nanohttpd.protocols.http.content.CookieHandler;
					public getParameters(): java.util.Map<any, any>;
					public getBodySize(): number;
					public getRemoteHostName(): string;
					public getRemoteIpAddress(): string;
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export class IHTTPSession {
					/**
					 * Constructs a new instance of the org.nanohttpd.protocols.http.IHTTPSession interface with the provided implementation.
					 */
					public constructor(implementation: {
						execute(): void;
						getCookies(): org.nanohttpd.protocols.http.content.CookieHandler;
						getHeaders(): java.util.Map<any, any>;
						getInputStream(): javaioInputStream;
						getMethod(): org.nanohttpd.protocols.http.request.Method;
						getParms(): java.util.Map<any, any>;
						getParameters(): java.util.Map<any, any>;
						getQueryParameterString(): string;
						getUri(): string;
						parseBody(param0: java.util.Map<any, any>): void;
						getRemoteIpAddress(): string;
						getRemoteHostName(): string;
					});
					public getParms(): java.util.Map<any, any>;
					public getQueryParameterString(): string;
					public parseBody(param0: java.util.Map<any, any>): void;
					public execute(): void;
					public getInputStream(): javaioInputStream;
					public getMethod(): org.nanohttpd.protocols.http.request.Method;
					public getCookies(): org.nanohttpd.protocols.http.content.CookieHandler;
					public getParameters(): java.util.Map<any, any>;
					public getUri(): string;
					public getHeaders(): java.util.Map<any, any>;
					public getRemoteHostName(): string;
					public getRemoteIpAddress(): string;
				}
			}
		}
	}
}

import javasecurityKeyStore = java.security.KeyStore;
import javaxnetsslKeyManager = javax.net.ssl.KeyManager;
import javaxnetsslSSLServerSocketFactory = javax.net.ssl.SSLServerSocketFactory;
import javaxnetsslKeyManagerFactory = javax.net.ssl.KeyManagerFactory;
import javalangObject = java.lang.Object;
import javanetServerSocket = java.net.ServerSocket;
import javautilregexPattern = java.util.regex.Pattern;
import javautilloggingLogger = java.util.logging.Logger;
import javautilList = java.util.List;
import javalangException = java.lang.Exception;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export abstract class NanoHTTPD {
					public static CONTENT_DISPOSITION_REGEX: string;
					public static CONTENT_DISPOSITION_PATTERN: javautilregexPattern;
					public static CONTENT_TYPE_REGEX: string;
					public static CONTENT_TYPE_PATTERN: javautilregexPattern;
					public static CONTENT_DISPOSITION_ATTRIBUTE_REGEX: string;
					public static CONTENT_DISPOSITION_ATTRIBUTE_PATTERN: javautilregexPattern;
					public static SOCKET_READ_TIMEOUT: number;
					public static MIME_PLAINTEXT: string;
					public static MIME_HTML: string;
					public static LOG: javautilloggingLogger;
					public static MIME_TYPES: java.util.Map<any, any>;
					public hostname: string;
					public myPort: number;
					public interceptors: java.util.List<any>;
					public asyncRunner: org.nanohttpd.protocols.http.threading.IAsyncRunner;
					public static makeSSLSocketFactory(param0: javasecurityKeyStore, param1: javaxnetsslKeyManagerFactory): javaxnetsslSSLServerSocketFactory;
					public getTempFileManagerFactory(): org.nanohttpd.util.IFactory;
					public static decodeParameters(param0: string): java.util.Map<any, any>;
					public setAsyncRunner(param0: org.nanohttpd.protocols.http.threading.IAsyncRunner): void;
					public getMyServerSocket(): javanetServerSocket;
					public setHTTPHandler(param0: org.nanohttpd.util.IHandler): void;
					public createServerRunnable(param0: number): org.nanohttpd.protocols.http.ServerRunnable;
					public setServerSocketFactory(param0: org.nanohttpd.util.IFactoryThrowing): void;
					public getListeningPort(): number;
					public handle(param0: org.nanohttpd.protocols.http.IHTTPSession): org.nanohttpd.protocols.http.response.Response;
					public setTempFileManagerFactory(param0: org.nanohttpd.util.IFactory): void;
					public start(): void;
					public closeAllConnections(): void;
					public getServerSocketFactory(): org.nanohttpd.util.IFactoryThrowing;
					public createClientHandler(param0: javanetSocket, param1: javaioInputStream): org.nanohttpd.protocols.http.ClientHandler;
					public serve(param0: org.nanohttpd.protocols.http.IHTTPSession): org.nanohttpd.protocols.http.response.Response;
					public constructor(param0: string, param1: number);
					public static safeClose(param0: javalangObject): void;
					public getHostname(): string;
					public constructor(param0: number);
					public isAlive(): boolean;
					public static makeSSLSocketFactory(param0: string, param1: native.Array<string>): javaxnetsslSSLServerSocketFactory;
					public static decodeParameters(param0: java.util.Map<any, any>): java.util.Map<any, any>;
					public static makeSSLSocketFactory(param0: javasecurityKeyStore, param1: native.Array<javaxnetsslKeyManager>): javaxnetsslSSLServerSocketFactory;
					public start(param0: number): void;
					public static decodePercent(param0: string): string;
					public static mimeTypes(): java.util.Map<any, any>;
					public addHTTPInterceptor(param0: org.nanohttpd.util.IHandler): void;
					public static getMimeTypeForFile(param0: string): string;
					public wasStarted(): boolean;
					public stop(): void;
					public start(param0: number, param1: boolean): void;
					public makeSecure(param0: javaxnetsslSSLServerSocketFactory, param1: native.Array<string>): void;
				}
				export module NanoHTTPD {
					export class ResponseException {
						public getStatus(): org.nanohttpd.protocols.http.response.Status;
						public constructor(param0: org.nanohttpd.protocols.http.response.Status, param1: string, param2: javalangException);
						public constructor(param0: org.nanohttpd.protocols.http.response.Status, param1: string);
					}
				}
			}
		}
	}
}

import javaioIOException = java.io.IOException;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export class ServerRunnable {
					public constructor(param0: org.nanohttpd.protocols.http.NanoHTTPD, param1: number);
					public hasBinded(): boolean;
					public run(): void;
					public getBindException(): javaioIOException;
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module content {
					export class ContentType {
						public getBoundary(): string;
						public getContentType(): string;
						public tryUTF8(): org.nanohttpd.protocols.http.content.ContentType;
						public getContentTypeHeader(): string;
						public isMultipart(): boolean;
						public getEncoding(): string;
						public constructor(param0: string);
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module content {
					export class Cookie {
						public static getHTTPTime(param0: number): string;
						public constructor(param0: string, param1: string, param2: string);
						public getHTTPHeader(): string;
						public constructor(param0: string, param1: string);
						public constructor(param0: string, param1: string, param2: number);
					}
				}
			}
		}
	}
}

import javautilIterator = java.util.Iterator;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module content {
					export class CookieHandler {
						public iterator(): java.util.Iterator<any>;
						public delete(param0: string): void;
						public unloadQueue(param0: org.nanohttpd.protocols.http.response.Response): void;
						public set(param0: org.nanohttpd.protocols.http.content.Cookie): void;
						public constructor(param0: java.util.Map<any, any>);
						public set(param0: string, param1: string, param2: number): void;
						public read(param0: string): string;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module request {
					export class Method {
						public static GET: org.nanohttpd.protocols.http.request.Method;
						public static PUT: org.nanohttpd.protocols.http.request.Method;
						public static POST: org.nanohttpd.protocols.http.request.Method;
						public static DELETE: org.nanohttpd.protocols.http.request.Method;
						public static HEAD: org.nanohttpd.protocols.http.request.Method;
						public static OPTIONS: org.nanohttpd.protocols.http.request.Method;
						public static TRACE: org.nanohttpd.protocols.http.request.Method;
						public static CONNECT: org.nanohttpd.protocols.http.request.Method;
						public static PATCH: org.nanohttpd.protocols.http.request.Method;
						public static PROPFIND: org.nanohttpd.protocols.http.request.Method;
						public static PROPPATCH: org.nanohttpd.protocols.http.request.Method;
						public static MKCOL: org.nanohttpd.protocols.http.request.Method;
						public static MOVE: org.nanohttpd.protocols.http.request.Method;
						public static COPY: org.nanohttpd.protocols.http.request.Method;
						public static LOCK: org.nanohttpd.protocols.http.request.Method;
						public static UNLOCK: org.nanohttpd.protocols.http.request.Method;
						public static NOTIFY: org.nanohttpd.protocols.http.request.Method;
						public static SUBSCRIBE: org.nanohttpd.protocols.http.request.Method;
						public static valueOf(param0: string): org.nanohttpd.protocols.http.request.Method;
						public static lookup(param0: string): org.nanohttpd.protocols.http.request.Method;
						public static values(): native.Array<org.nanohttpd.protocols.http.request.Method>;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module response {
					export class ChunkedOutputStream {
						public write(param0: number): void;
						public finish(): void;
						public write(param0: native.Array<number>, param1: number, param2: number): void;
						public write(param0: native.Array<number>): void;
						public constructor(param0: javaioOutputStream);
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module response {
					export class IStatus {
						/**
						 * Constructs a new instance of the org.nanohttpd.protocols.http.response.IStatus interface with the provided implementation.
						 */
						public constructor(implementation: {
							getDescription(): string;
							getRequestStatus(): number;
						});
						public getRequestStatus(): number;
						public getDescription(): string;
					}
				}
			}
		}
	}
}

import javaioPrintWriter = java.io.PrintWriter;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module response {
					export class Response {
						public close(): void;
						public setData(param0: javaioInputStream): void;
						public getData(): javaioInputStream;
						public send(param0: javaioOutputStream): void;
						public printHeader(param0: javaioPrintWriter, param1: string, param2: string): void;
						public setRequestMethod(param0: org.nanohttpd.protocols.http.request.Method): void;
						public setStatus(param0: org.nanohttpd.protocols.http.response.IStatus): void;
						public static newFixedLengthResponse(param0: string): org.nanohttpd.protocols.http.response.Response;
						public closeConnection(param0: boolean): void;
						public static newFixedLengthResponse(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: native.Array<number>): org.nanohttpd.protocols.http.response.Response;
						public static newFixedLengthResponse(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: javaioInputStream, param3: number): org.nanohttpd.protocols.http.response.Response;
						public useGzipWhenAccepted(): boolean;
						public constructor(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: javaioInputStream, param3: number);
						public setMimeType(param0: string): void;
						public getCookieHeaders(): java.util.List<any>;
						public isCloseConnection(): boolean;
						public getRequestMethod(): org.nanohttpd.protocols.http.request.Method;
						public getStatus(): org.nanohttpd.protocols.http.response.IStatus;
						public addHeader(param0: string, param1: string): void;
						public setKeepAlive(param0: boolean): void;
						public static newFixedLengthResponse(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: string): org.nanohttpd.protocols.http.response.Response;
						public setChunkedTransfer(param0: boolean): void;
						public sendContentLengthHeaderIfNotAlreadyPresent(param0: javaioPrintWriter, param1: number): number;
						public addCookieHeader(param0: string): void;
						public getMimeType(): string;
						public setUseGzip(param0: boolean): org.nanohttpd.protocols.http.response.Response;
						public static newChunkedResponse(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: javaioInputStream): org.nanohttpd.protocols.http.response.Response;
						public getHeader(param0: string): string;
					}
					export module Response {
						export class GzipUsage {
							public static DEFAULT: org.nanohttpd.protocols.http.response.Response.GzipUsage;
							public static ALWAYS: org.nanohttpd.protocols.http.response.Response.GzipUsage;
							public static NEVER: org.nanohttpd.protocols.http.response.Response.GzipUsage;
							public static values(): native.Array<org.nanohttpd.protocols.http.response.Response.GzipUsage>;
							public static valueOf(param0: string): org.nanohttpd.protocols.http.response.Response.GzipUsage;
						}
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module response {
					export class Status {
						public static SWITCH_PROTOCOL: org.nanohttpd.protocols.http.response.Status;
						public static OK: org.nanohttpd.protocols.http.response.Status;
						public static CREATED: org.nanohttpd.protocols.http.response.Status;
						public static ACCEPTED: org.nanohttpd.protocols.http.response.Status;
						public static NO_CONTENT: org.nanohttpd.protocols.http.response.Status;
						public static PARTIAL_CONTENT: org.nanohttpd.protocols.http.response.Status;
						public static MULTI_STATUS: org.nanohttpd.protocols.http.response.Status;
						public static REDIRECT: org.nanohttpd.protocols.http.response.Status;
						public static FOUND: org.nanohttpd.protocols.http.response.Status;
						public static REDIRECT_SEE_OTHER: org.nanohttpd.protocols.http.response.Status;
						public static NOT_MODIFIED: org.nanohttpd.protocols.http.response.Status;
						public static TEMPORARY_REDIRECT: org.nanohttpd.protocols.http.response.Status;
						public static BAD_REQUEST: org.nanohttpd.protocols.http.response.Status;
						public static UNAUTHORIZED: org.nanohttpd.protocols.http.response.Status;
						public static FORBIDDEN: org.nanohttpd.protocols.http.response.Status;
						public static NOT_FOUND: org.nanohttpd.protocols.http.response.Status;
						public static METHOD_NOT_ALLOWED: org.nanohttpd.protocols.http.response.Status;
						public static NOT_ACCEPTABLE: org.nanohttpd.protocols.http.response.Status;
						public static REQUEST_TIMEOUT: org.nanohttpd.protocols.http.response.Status;
						public static CONFLICT: org.nanohttpd.protocols.http.response.Status;
						public static GONE: org.nanohttpd.protocols.http.response.Status;
						public static LENGTH_REQUIRED: org.nanohttpd.protocols.http.response.Status;
						public static PRECONDITION_FAILED: org.nanohttpd.protocols.http.response.Status;
						public static PAYLOAD_TOO_LARGE: org.nanohttpd.protocols.http.response.Status;
						public static UNSUPPORTED_MEDIA_TYPE: org.nanohttpd.protocols.http.response.Status;
						public static RANGE_NOT_SATISFIABLE: org.nanohttpd.protocols.http.response.Status;
						public static EXPECTATION_FAILED: org.nanohttpd.protocols.http.response.Status;
						public static TOO_MANY_REQUESTS: org.nanohttpd.protocols.http.response.Status;
						public static INTERNAL_ERROR: org.nanohttpd.protocols.http.response.Status;
						public static NOT_IMPLEMENTED: org.nanohttpd.protocols.http.response.Status;
						public static SERVICE_UNAVAILABLE: org.nanohttpd.protocols.http.response.Status;
						public static UNSUPPORTED_HTTP_VERSION: org.nanohttpd.protocols.http.response.Status;
						public static valueOf(param0: string): org.nanohttpd.protocols.http.response.Status;
						public static lookup(param0: number): org.nanohttpd.protocols.http.response.Status;
						public getRequestStatus(): number;
						public getDescription(): string;
						public static values(): native.Array<org.nanohttpd.protocols.http.response.Status>;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module sockets {
					export class DefaultServerSocketFactory {
						public constructor();
						public create(): javalangObject;
						public create(): javanetServerSocket;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module sockets {
					export class SecureServerSocketFactory {
						public create(): javalangObject;
						public create(): javanetServerSocket;
						public constructor(param0: javaxnetsslSSLServerSocketFactory, param1: native.Array<string>);
					}
				}
			}
		}
	}
}

import javaioFile = java.io.File;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module tempfiles {
					export class DefaultTempFile {
						public constructor(param0: javaioFile);
						public delete(): void;
						public open(): javaioOutputStream;
						public getName(): string;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module tempfiles {
					export class DefaultTempFileManager {
						public constructor();
						public createTempFile(param0: string): org.nanohttpd.protocols.http.tempfiles.ITempFile;
						public clear(): void;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module tempfiles {
					export class DefaultTempFileManagerFactory {
						public create(): org.nanohttpd.protocols.http.tempfiles.ITempFileManager;
						public constructor();
						public create(): javalangObject;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module tempfiles {
					export class ITempFile {
						/**
						 * Constructs a new instance of the org.nanohttpd.protocols.http.tempfiles.ITempFile interface with the provided implementation.
						 */
						public constructor(implementation: {
							delete(): void;
							getName(): string;
							open(): javaioOutputStream;
						});
						public delete(): void;
						public open(): javaioOutputStream;
						public getName(): string;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module tempfiles {
					export class ITempFileManager {
						/**
						 * Constructs a new instance of the org.nanohttpd.protocols.http.tempfiles.ITempFileManager interface with the provided implementation.
						 */
						public constructor(implementation: {
							clear(): void;
							createTempFile(param0: string): org.nanohttpd.protocols.http.tempfiles.ITempFile;
						});
						public createTempFile(param0: string): org.nanohttpd.protocols.http.tempfiles.ITempFile;
						public clear(): void;
					}
				}
			}
		}
	}
}

import javalangThread = java.lang.Thread;
declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module threading {
					export class DefaultAsyncRunner {
						public requestCount: number;
						public constructor();
						public getRunning(): java.util.List<any>;
						public closed(param0: org.nanohttpd.protocols.http.ClientHandler): void;
						public closeAll(): void;
						public exec(param0: org.nanohttpd.protocols.http.ClientHandler): void;
						public createThread(param0: org.nanohttpd.protocols.http.ClientHandler): javalangThread;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module protocols {
			export module http {
				export module threading {
					export class IAsyncRunner {
						/**
						 * Constructs a new instance of the org.nanohttpd.protocols.http.threading.IAsyncRunner interface with the provided implementation.
						 */
						public constructor(implementation: {
							closeAll(): void;
							closed(param0: org.nanohttpd.protocols.http.ClientHandler): void;
							exec(param0: org.nanohttpd.protocols.http.ClientHandler): void;
						});
						public closed(param0: org.nanohttpd.protocols.http.ClientHandler): void;
						public closeAll(): void;
						public exec(param0: org.nanohttpd.protocols.http.ClientHandler): void;
					}
				}
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module util {
			export class IFactory {
				/**
				 * Constructs a new instance of the org.nanohttpd.util.IFactory interface with the provided implementation.
				 */
				public constructor(implementation: {
					create(): javalangObject;
				});
				public create(): javalangObject;
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module util {
			export class IFactoryThrowing {
				/**
				 * Constructs a new instance of the org.nanohttpd.util.IFactoryThrowing interface with the provided implementation.
				 */
				public constructor(implementation: {
					create(): javalangObject;
				});
				public create(): javalangObject;
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module util {
			export class IHandler {
				/**
				 * Constructs a new instance of the org.nanohttpd.util.IHandler interface with the provided implementation.
				 */
				public constructor(implementation: {
					handle(param0: javalangObject): javalangObject;
				});
				public handle(param0: javalangObject): javalangObject;
			}
		}
	}
}

import javalangClass = java.lang.Class;
declare module org {
	export module nanohttpd {
		export module util {
			export class ServerRunner {
				public static run(param0: java.lang.Class<any>): void;
				public static executeInstance(param0: org.nanohttpd.protocols.http.NanoHTTPD): void;
				public constructor();
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module webserver {
			export class InternalRewrite extends org.nanohttpd.protocols.http.response.Response {
				public constructor(param0: java.util.Map<any, any>, param1: string);
				public getUri(): string;
				public constructor(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: javaioInputStream, param3: number);
				public getHeaders(): java.util.Map<any, any>;
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module webserver {
			export class SimpleWebServer extends org.nanohttpd.protocols.http.NanoHTTPD {
				public static INDEX_FILE_NAMES: java.util.List<any>;
				public rootDirs: java.util.List<any>;
				public static DEFAULT_ALLOWED_HEADERS: string;
				public static ACCESS_CONTROL_ALLOW_HEADER_PROPERTY_NAME: string;
				public constructor(param0: string, param1: number, param2: java.util.List<any>, param3: boolean);
				public constructor(param0: string, param1: number, param2: java.util.List<any>, param3: boolean, param4: string);
				public init(): void;
				public getNotFoundResponse(): org.nanohttpd.protocols.http.response.Response;
				public constructor(param0: string, param1: number, param2: javaioFile, param3: boolean);
				public getForbiddenResponse(param0: string): org.nanohttpd.protocols.http.response.Response;
				public static newFixedLengthResponse(param0: org.nanohttpd.protocols.http.response.IStatus, param1: string, param2: string): org.nanohttpd.protocols.http.response.Response;
				public constructor(param0: string, param1: number);
				public addCORSHeaders(param0: java.util.Map<any, any>, param1: org.nanohttpd.protocols.http.response.Response, param2: string): org.nanohttpd.protocols.http.response.Response;
				public constructor(param0: string, param1: number, param2: javaioFile, param3: boolean, param4: string);
				public getInternalErrorResponse(param0: string): org.nanohttpd.protocols.http.response.Response;
				public listDirectory(param0: string, param1: javaioFile): string;
				public constructor(param0: number);
				public serve(param0: org.nanohttpd.protocols.http.IHTTPSession): org.nanohttpd.protocols.http.response.Response;
				public static main(param0: native.Array<string>): void;
				public static registerPluginForMimeType(param0: native.Array<string>, param1: string, param2: org.nanohttpd.webserver.WebServerPlugin, param3: java.util.Map<any, any>): void;
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module webserver {
			export class WebServerPlugin {
				/**
				 * Constructs a new instance of the org.nanohttpd.webserver.WebServerPlugin interface with the provided implementation.
				 */
				public constructor(implementation: {
					canServeUri(param0: string, param1: javaioFile): boolean;
					initialize(param0: java.util.Map<any, any>): void;
					serveFile(param0: string, param1: java.util.Map<any, any>, param2: org.nanohttpd.protocols.http.IHTTPSession, param3: javaioFile, param4: string): org.nanohttpd.protocols.http.response.Response;
				});
				public canServeUri(param0: string, param1: javaioFile): boolean;
				public initialize(param0: java.util.Map<any, any>): void;
				public serveFile(param0: string, param1: java.util.Map<any, any>, param2: org.nanohttpd.protocols.http.IHTTPSession, param3: javaioFile, param4: string): org.nanohttpd.protocols.http.response.Response;
			}
		}
	}
}

declare module org {
	export module nanohttpd {
		export module webserver {
			export class WebServerPluginInfo {
				/**
				 * Constructs a new instance of the org.nanohttpd.webserver.WebServerPluginInfo interface with the provided implementation.
				 */
				public constructor(implementation: {
					getIndexFilesForMimeType(param0: string): native.Array<string>;
					getMimeTypes(): native.Array<string>;
					getWebServerPlugin(param0: string): org.nanohttpd.webserver.WebServerPlugin;
				});
				public getMimeTypes(): native.Array<string>;
				public getIndexFilesForMimeType(param0: string): native.Array<string>;
				public getWebServerPlugin(param0: string): org.nanohttpd.webserver.WebServerPlugin;
			}
		}
	}
}

