export declare class HttpServer {
    _webServer: GCDWebServer;
    _address: string;
    private _defaultPort;
    private _defaultAddress;
    constructor(address?: string, port?: number);
    serveWithHtml(html: string): string;
    serveWithStaticHtmlFromPath(directoryPath: string): string;
    stopServing(): void;
}
export declare var GCDWebServerInstance: GCDWebServer;
// export declare class GCDWebServerCopy extends GCDWebServer {

// }
export declare class HttpServerDelegate extends NSObject implements GCDWebDAVServerDelegate {
    webServerDidCompleteBonjourRegistration(server: GCDWebServer): void;
    webServerDidConnect(server: GCDWebServer): void;
    webServerDidDisconnect(server: GCDWebServer): void;
    webServerDidStart(server: GCDWebServer): void;
    webServerDidStop(server: GCDWebServer): void;
    webServerDidUpdateNATPortMapping(server: GCDWebServer): void;
    static ObjCProtocols: {
        prototype: GCDWebDAVServerDelegate;
    }[];
    static new(): HttpServerDelegate;
}
