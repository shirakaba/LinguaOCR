"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fileModule = require("tns-core-modules/file-system");
var HttpServer = (function () {
    function HttpServer(address, port) {
        this._defaultPort = 8183;
        this._defaultAddress = '127.0.0.1';
        if (address && typeof address === 'string') {
            this._defaultAddress = address.replace('http', '');
        }
        if (port && port > 8000) {
            this._defaultPort = port;
        }
    }
    HttpServer.prototype.serveWithHtml = function (html) {
        var tempFolder = fileModule.knownFolders.temp();
        var pathHtml = fileModule.path.join(tempFolder.path, 'index.html');
        this._tempFile = fileModule.File.fromPath(pathHtml);
        this._tempFile.writeText(html)
            .then(function () {
        }, function (error) {
            console.log('Failed to init temporary file for htm', error);
        });
        if (this._webServer != null)
            this.stopServing();
        this._webServer = new org.nanohttpd.webserver.SimpleWebServer(this._defaultAddress, this._defaultPort, new java.io.File(tempFolder.path), false);
        console.log('webServer', this._webServer);
        return this.startServing();
    };
    HttpServer.prototype.serveWithStaticHtmlFromPath = function (directoryPath) {
        if (this._webServer != null)
            this.stopServing();
        this._webServer = new org.nanohttpd.webserver.SimpleWebServer(this._defaultAddress, this._defaultPort, new java.io.File(directoryPath), false);
        console.log('webServer', this._webServer);
        return this.startServing();
    };
    HttpServer.prototype.startServing = function () {
        try {
            if (this._webServer == null)
                return null;
            this._webServer.start();
            this._address = 'http://' + this._defaultAddress + ':' + this._defaultPort;
        }
        catch (error) {
            console.log('NanoHTTP server failed to start', error);
        }
        return this._address;
    };
    HttpServer.prototype.stopServing = function () {
        try {
            if (this._webServer != null)
                this._webServer.stop();
            if (this._tempFile != null)
                this._tempFile.remove();
        }
        catch (error) {
            console.log("ERROR: cannot stop server", error);
        }
    };
    return HttpServer;
}());
exports.HttpServer = HttpServer;
//# sourceMappingURL=httpserver.android.js.map