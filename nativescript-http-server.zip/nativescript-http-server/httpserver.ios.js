"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HttpServer = (function () {
    function HttpServer(address, port) {
        this._defaultPort = 8183;
        this._defaultAddress = '127.0.0.1';
        if (address && typeof address === 'string') {
            this._defaultAddress = address.replace('http', '');
        }
        if (port && port > 8000) {
            this._defaultPort = port;
        }
        this._webServer = GCDWebServer.alloc().init();
        this._webServer.delegate = new HttpServerDelegate();
        console.log('webServer', this._webServer);
    }
    HttpServer.prototype.serveWithHtml = function (html) {
        this._webServer.addDefaultHandlerForMethodRequestClassAsyncProcessBlock("GET", GCDWebServerRequest.class(), function (request) {
            console.log("got request");
            var response = GCDWebServerDataResponse.alloc().initWithHTML(html);
            console.log("prepared response %o", response);
            return response;
        });
        this._webServer.startWithPortBonjourName(this._defaultPort, "GCD Web Server");
        console.log("server started at :" + this._webServer.serverURL);
        this._address = this._webServer.serverURL ? this._webServer.serverURL.toString() : 'http://' + this._defaultAddress + ':8183';
        return this._address;
    };
    HttpServer.prototype.serveWithStaticHtmlFromPath = function (directoryPath) {
        this._webServer.addGETHandlerForBasePathDirectoryPathIndexFilenameCacheAgeAllowRangeRequests("/", directoryPath, 'index.html', 0, true);
        this._webServer.startWithPortBonjourName(this._defaultPort, "GCD Web Server");
        console.log("server started at :" + this._webServer.serverURL);
        this._address = this._webServer.serverURL ? this._webServer.serverURL.toString() : 'http://' + this._defaultAddress + ':8183';
        return this._address;
    };
    HttpServer.prototype.stopServing = function () {
        this._webServer && this._webServer.stop();
    };
    return HttpServer;
}());
exports.HttpServer = HttpServer;
// var GCDWebServerCopy = (function GCDWebServerCopy() {
//     return GCDWebServer;
// }());
// exports.GCDWebServerCopy = GCDWebServerCopy;
exports.GCDWebServerInstance = GCDWebServer.alloc().init();
var HttpServerDelegate = (function (_super) {
    __extends(HttpServerDelegate, _super);
    function HttpServerDelegate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    HttpServerDelegate.prototype.webServerDidCompleteBonjourRegistration = function (server) {
        console.log("webServerDidCompleteBonjourRegistration");
    };
    HttpServerDelegate.prototype.webServerDidConnect = function (server) {
        console.log("webServerDidConnect");
    };
    HttpServerDelegate.prototype.webServerDidDisconnect = function (server) {
        console.log("webServerDidDisconnect");
    };
    HttpServerDelegate.prototype.webServerDidStart = function (server) {
        console.log("webServerDidStart");
    };
    HttpServerDelegate.prototype.webServerDidStop = function (server) {
        console.log("webServerDidStop");
    };
    HttpServerDelegate.prototype.webServerDidUpdateNATPortMapping = function (server) {
        console.log("webServerDidUpdateNATPortMapping");
    };
    HttpServerDelegate.new = function () {
        return _super.new.call(this);
    };
    HttpServerDelegate.ObjCProtocols = [GCDWebDAVServerDelegate];
    return HttpServerDelegate;
}(NSObject));
exports.HttpServerDelegate = HttpServerDelegate;
//# sourceMappingURL=httpserver.ios.js.map