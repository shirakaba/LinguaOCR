/// <reference path="./typings/objc!GCDWebServer.d.ts" />

export declare class HttpServer {
	_webServer: GCDWebServer;
	_address: string;
	serveWithHtml(html: string): string;
	serveWithStaticHtmlFromPath(directoryPath: string): string;
	stopServing(): void;
}
export declare var GCDWebServerInstance: GCDWebServer;
// export declare var GCDWebServer: GCDWebServer;
// export declare class GCDWebServerCopy extends GCDWebServer {
    
// }