export declare class HttpServer {
    _webServer: org.nanohttpd.webserver.SimpleWebServer;
    _address: string;
    private _defaultPort;
    private _defaultAddress;
    private _tempFile;
    constructor(address?: string, port?: number);
    serveWithHtml(html: string): string;
    serveWithStaticHtmlFromPath(directoryPath: string): string;
    private startServing();
    stopServing(): void;
}
